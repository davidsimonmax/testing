package com.github.jengelman.gradle.plugins.shadow.docs.internal.snippets.fixture;

class GroovyScriptFixture extends SnippetFixture {

  @Override
  String post() {
    "\n;0;"
  }

}
