package com.github.jengelman.gradle.plugins.shadow.util.repo.maven

public interface MavenMetaData {
    List<String> getVersions();

}
