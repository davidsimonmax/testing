package com.github.jengelman.gradle.plugins.shadow.docs.internal.snippets;

public interface CodeSnippetTests {

  void add(TestCodeSnippet testCodeSnippet);

}
