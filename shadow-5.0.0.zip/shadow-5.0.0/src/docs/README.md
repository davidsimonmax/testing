---
home: true
heroText: Gradle Shadow Plugin
heroImage: /logo.svg
tagline: The library author's dependency toolkit
actionText: User Guide →
actionLink: /introduction/
---

John Engelman - @johnrengelman

[API Docs](http://imperceptiblethoughts.com/shadow/api/index.html)
