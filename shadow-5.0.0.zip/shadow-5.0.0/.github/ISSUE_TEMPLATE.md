Please check the [User Guide](http://imperceptiblethoughts.com/shadow) before submitting "how do I do 'x'?" questions!

### Shadow Version

### Gradle Version

### Expected Behavior

### Actual Behavior

### Gradle Build Script(s)

### Content of Shadow JAR (`jar tf <jar file>` - post link to GIST if too long)
